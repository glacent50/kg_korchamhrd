`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/22 21:40:27
// Design Name: 
// Module Name: ov7670_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ov7670_top(
    input  clk100,
    input  OV7670_VSYNC, // SCCB 프로토콜 수직 동기 신호 입력
    input  OV7670_HREF,  // SCCB 프로토콜 수평 동기 신호 입력
    input  OV7670_PCLK,  // 픽셀 클럭 입력
    output OV7670_XCLK,  // 카메라 모듈에 공급되는 클럭 출력
    output OV7670_SIOC, 
    inout  OV7670_SIOD,
    input [7:0] OV7670_D, // 데이터 버스 입력
    
    output[3:0] LED,
    output[3:0] vga_red,
    output[3:0] vga_green,
    output[3:0] vga_blue,
    output vga_hsync, // 수평 동기 신호 출력
    output vga_vsync, // 수직 동기 신호 출력
    
    input reset_p,
    output pwdn,
    output reset
);

    wire [16:0] frame_addr;
    wire [16:0] capture_addr;   
    //wire  capture_we;  
    wire  config_finished;  
    wire  clk25; 
    wire  clk50;     
    wire  resend;        
    wire [11:0] frame_pixel;  
    wire [11:0]  data_16;
      
    assign pwdn = 0; // 0은 전원 켜짐 모드, 1은 저전력 모드
    assign reset = 1;
      
    assign LED = {3'b0,config_finished};
    assign  	OV7670_XCLK = clk25;
    
    clk_wiz_0 clk_div(
        .clk_in1 (clk100),
        .clk_out1  (clk50),
        .clk_out2 (clk25)
    );
    
    debounce btn_debounce(
		.clk(clk50),
		.i(reset_p),
		.o(resend)
    );

     vga_disp vga_display (
            .clk25(clk25),
            .vga_red(vga_red),
            .vga_green(vga_green),
            .vga_blue(vga_blue),
            .vga_hsync(vga_hsync),
            .vga_vsync(vga_vsync),
            .HCnt(),
            .VCnt(),
    
            .frame_addr(frame_addr),
            .frame_pixel(frame_pixel)
     );
    
     blk_mem_gen_0 u_frame_buffer(
            .clka(OV7670_PCLK),
            .wea(1'b1),
            .addra(capture_addr),
            .dina(data_16),
    
            .clkb(clk25),
            .addrb(frame_addr),
            .doutb(frame_pixel)
     );
         
    ov7670_capture capture(         // OV7670 카메라 모듈 데이터 캡처
		.pclk  (OV7670_PCLK),    // 픽셀 클럭 입력
		.vsync (OV7670_VSYNC),   // 수직 동기 신호 입력
		.href  (OV7670_HREF),    // 수평 동기 신호 입력
		.d     ( OV7670_D),      // 이미지 데이터 입력
		.addr  (capture_addr),   // 저장 주소 출력
		.dout( data_12),         // 12비트 데이터 출력
		.we   ()
	);   
	
    I2C_AV_Config IIC(                 // 카메라 모듈 SCCB 프로토콜 구현
		.iCLK   ( clk25),          // 25MHz 클럭 입력
		.iRST_N (! resend),        // 리셋 신호 입력
		.Config_Done ( config_finished),    // OV7670 레지스터 설정 완료 후 config_finished 신호 출력
		.I2C_SDAT  ( OV7670_SIOD),   // 데이터 신호
		.I2C_SCLK  ( OV7670_SIOC),   // 클럭 신호
		.LUT_INDEX (),
		.I2C_RDATA ()
	); 	
	      
    
endmodule
