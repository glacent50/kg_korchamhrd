`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/17/2025 10:14:34 AM
// Design Name: 
// Module Name: vga_disp_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module vga_disp_top(
    input clk100,          // 100MHz 시스템 클럭
    input reset_p,             // 리셋 버튼 (Center button)
    output [3:0] vga_red,   
    output [3:0] vga_green,
    output [3:0] vga_blue,
    output vga_hsync,
    output vga_vsync,
    output [3:0] LED       // 디버깅용 LED
    );


    
    // 내부 신호
    wire [9:0] h_cnt, v_cnt;
    wire [16:0] frame_addr;
    wire [11:0] frame_pixel;
    wire reset;
    
    
    // 리셋 신호 (버튼을 누르면 리셋) 리셋 신호 (Active Low로 변환)
    assign reset = reset_p;
    
    
    wire  clk25;         // 25MHz VGA 클럭
    wire  clk50;         // 50MHz Reset 클럭    
    clk_wiz_0 clk_div(
        .clk_in1 (clk100),
        .clk_out1  (clk50),
        .clk_out2 (clk25)
    );
        
    // VGA 모듈 인스턴스화
    vga_disp vga_inst (
        .clk25(clk25),
        .vga_red(vga_red),
        .vga_green(vga_green),
        .vga_blue(vga_blue),
        .vga_hsync(vga_hsync),
        .vga_vsync(vga_vsync),
        .HCnt(h_cnt),
        .VCnt(v_cnt),
        .frame_addr(frame_addr),
        .frame_pixel(frame_pixel)
    );
    
    
    // 메모리 초기화용 신호들
    reg [16:0] init_addr;
    reg [11:0] init_data;
    reg init_we;
    reg init_done;
    
    reg [19:0] init_counter;
    reg [19:0] data_h_cnt;
    reg [19:0] data_v_cnt;
    
    // Block Memory Generator IP 인스턴스화
    // Vivado에서 생성된 blk_mem_gen_0 IP를 사용
    blk_mem_gen_0 frame_buffer (
        // Port A - 초기화 및 쓰기용
        .clka(clk25),
        .ena(1'b1),
        .wea(init_we),
        .addra(init_done ? 17'd0 : init_addr),
        .dina(init_data),
        
        // Port B - 읽기용 (VGA 출력)
        .clkb(clk25),
        .enb(1'b1),
        .addrb(frame_addr),
        .doutb(frame_pixel)
    );
    
    
    // 640 x 480 출력 중 vga_disp는 320 x 240 영역만 프레임버퍼를 사용
    // 메모리 초기화 상태 머신: 320x240 프레임버퍼를 세로 3등분(R/G/B)으로 채움
    always @(posedge clk25 or negedge reset) begin
        if (!reset) begin
            init_counter <= 0;
            init_addr <= 0;
            init_we <= 1;
            init_done <= 0;
            init_data <= 0;
        end
        else begin
            if (!init_done) begin
                // vga_disp의 address 증가 영역은 320x240 = 76800 깊이
                if (init_counter < 76800) begin
                    // black mem add setting. 한번 만 그려짐..
                    init_addr <= init_counter[16:0];                    
                    // (x,y) = (init_counter % 320, init_counter / 320)
                    data_h_cnt = init_counter % 320;
                    data_v_cnt = init_counter / 320;

                    // 세로 3등분: 좌(0~106)=RED, 중간(107~213)=GREEN, 우(214~319)=BLUE
                    if (data_h_cnt < 107)
                        init_data = 12'hF00; // RED
                    else if (data_h_cnt < 214)
                        init_data = 12'h0F0; // GREEN
                    else
                        init_data = 12'h00F; // BLUE

                    //--display
                    
                    //--end
            
            
            
                    init_counter <= init_counter + 1;
                    init_we <= 1;
                end
                else begin
                    init_done <= 1;
                    init_we <= 0;
                end
            end
        end    
    end
    
    
    
    // // 테스트 패턴 생성 로직
    // always @(*) begin
    //     frame_pixel = 12'h000; // 기본값: 검은색
        
    //     // 화면 영역 체크 (640x480 해상도)
    //     if (h_cnt < 640 && v_cnt < 480) begin
    //         // 화면을 세 개 영역으로 분할
    //         if (h_cnt < 213) begin
    //             // 좌측 1/3: 빨간색 그라데이션
    //             //frame_pixel = {h_cnt[7:4], 8'h00};
    //             frame_pixel = 12'hF00;
    //         end else if (h_cnt < 426) begin
    //             // 중앙 1/3: 녹색 그라데이션
    //             //frame_pixel = {4'h0, h_cnt[7:4], 4'h0};
    //             frame_pixel = 12'h0F0;
    //         end else begin
    //             // 우측 1/3: 파란색 그라데이션
    //             //frame_pixel = {8'h00, h_cnt[7:4]};
    //             frame_pixel = 12'h00F;
    //         end
            
    //         // 가로 중앙선 (화면 중앙에 흰색 선)
    //         if (v_cnt == 240)
    //             frame_pixel = 12'hFFF;
                
    //         // 세로 중앙선 (화면 중앙에 흰색 선)
    //         if (h_cnt == 320)
    //             frame_pixel = 12'hFFF;
                
    //         // 테스트 박스 (좌상단에 작은 흰색 사각형)
    //         if (h_cnt >= 10 && h_cnt < 50 && v_cnt >= 10 && v_cnt < 50)
    //             frame_pixel = 12'hFFF;
    //     end
    // end
    
    
    // 디버깅용 LED - 동작 상태 표시
    assign LED[0] = clk25;           // 25MHz 클럭 표시
    assign LED[1] = |h_cnt[9:8];     // 수평 카운터 상위 비트
    assign LED[2] = |v_cnt[9:8];     // 수직 카운터 상위 비트  
    assign LED[3] = ~reset;          // 리셋 상태 (리셋 안될 때 켜짐)
    
endmodule


module clk_wiz_debug_top(
    input clk100,          // 100MHz 시스템 클럭
    input reset_p,             // 리셋 버튼 (Center button)
    output reg [1:0] LED       // 디버깅용 LED
    );
    
    wire clk50, clk25;     // 생성될 클록 신호들
    wire locked;           // PLL 락 신호

    //clk_in1: 100MHz 입력 클록
    //clk_out1: 50MHz 출력 클록
    //clk_out2: 25MHz 출력 클록
    //reset: 리셋 입력 (옵션)
    //locked: MMCM이 안정된 클록을 생성하고 있음을 나타내는 출력 신호
    

    // Clock Wizard IP 인스턴스
    clk_wiz_0 clk_div(
        .clk_in1(clk100),  // 100MHz 입력
        .clk_out1(clk50),  // 50MHz 출력
        .clk_out2(clk25),  // 25MHz 출력
        .reset(reset_p),   // 리셋 입력
        .locked(locked)    // PLL 락 출력
    );
    
    
    // 50MHz 클록 도메인
    reg [25:0] counter50;
    always @(posedge clk50 or posedge reset_p) begin
        if (reset_p || !locked) begin
            counter50 <= 0;
            LED[0] <= 0;
        end else begin
            counter50 <= counter50 + 1;
            if (counter50 >= 25000000) begin  // 0.5초
                LED[0] <= ~LED[0];
                counter50 <= 0;
            end
        end
    end    
        
    // 25MHz 클록 도메인  
    reg [24:0] counter25;
    always @(posedge clk25 or posedge reset_p) begin
        if (reset_p || !locked) begin
            counter25 <= 0;
            LED[1] <= 0;
        end else begin
            counter25 <= counter25 + 1;
            if (counter25 >= 12500000) begin  // 0.5초
                LED[1] <= ~LED[1];
                counter25 <= 0;
            end
        end
    end    
    
endmodule    
    