`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/22/2025 11:11:29 AM
// Design Name: 
// Module Name: i2c_master_combined
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// 레지스터 기반 센서에 특화된 I2C 복합 트랜잭션 마스터.
// 지원 동작: Start -> [주소+W] -> 레지스터 주소 -> [옵션: 쓰기 바이트] -> [옵션: 반복 Start -> 주소+R -> 읽기 바이트] -> Stop
// 오픈 드레인 SCL/SDA (로우 구동 또는 하이 릴리스). 클럭 스트레칭은 지원하지 않음.
// 파라미터: CLK_FREQ (Hz), I2C_FREQ (Hz)
module i2c_master_combined #(
    parameter integer CLK_FREQ = 100_000_000,
    parameter integer I2C_FREQ = 100_000
)(
    input  wire        clk,
    input  wire        rst_n,

    // 트랜잭션 설명자
    input  wire        start,         // 트랜잭션을 시작하기 위한 펄스
    input  wire [6:0]  dev_addr,      // 7비트 I2C 주소 (예: BMP085의 경우 7'h77)
    input  wire [7:0]  reg_addr,      // 레지스터 주소
    input  wire [1:0]  wlen,          // 쓸 데이터 바이트 수 (0..3)
    input  wire [23:0] wdata,         // 쓰기 데이터 페이로드. 바이트 순서: [23:16]=byte2, [15:8]=byte1, [7:0]=byte0
    input  wire [2:0]  rlen,          // 읽을 바이트 수 (0..4)

    // 상태
    output reg         busy,
    output reg         done,          // 전체 트랜잭션이 완료될 때 1-사이클 펄스
    output reg         ack_error,     // 슬레이브 NACK 발생 시 하이 (다음 시작까지 유지)

    // 읽기 데이터
    output reg  [31:0] rdata,         // 읽기 페이로드 (MSB 우선): 첫 바이트는 [31:24]
    output reg  [2:0]  rcount,        // rdata에 채워진 바이트 수
    output reg         rvalid,        // rdata/rcount가 유효할 때 1-사이클 펄스 (트랜잭션 종료 시)

    // I2C 라인 (오픈 드레인)
    inout  wire        i2c_scl,
    inout  wire        i2c_sda
);

    // 오픈 드레인 드라이버
    reg scl_oe_n; // 1: 릴리스 (Z=하이), 0: 로우 구동
    reg sda_oe_n; // 1: 릴리스, 0: 로우 구동
    assign i2c_scl = scl_oe_n ? 1'bz : 1'b0;
    assign i2c_sda = sda_oe_n ? 1'bz : 1'b0;

    wire sda_in = i2c_sda;

    // SCL 반주기 인에이블 생성을 위한 클럭 분배기
    localparam integer HALF_TICKS = (CLK_FREQ/(I2C_FREQ*2));
    localparam integer CNTW = $clog2(HALF_TICKS);
    reg [CNTW-1:0] div_cnt;
    reg            tick;       // SCL 토글을 위한 반주기 틱

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            div_cnt <= 0;
            tick    <= 1'b0;
        end else if (busy) begin
            if (div_cnt == HALF_TICKS-1) begin
                div_cnt <= 0;
                tick    <= 1'b1;
            end else begin
                div_cnt <= div_cnt + 1'b1;
                tick    <= 1'b0;
            end
        end else begin
            div_cnt <= 0;
            tick    <= 1'b0;
        end
    end

    reg scl_high;

    reg [7:0] byte_tx;
    reg [2:0] bit_idx;
    reg       byte_phase;

    localparam [3:0] ST_IDLE        = 4'd0;
    localparam [3:0] ST_START_A     = 4'd1;
    localparam [3:0] ST_START_B     = 4'd2;
    localparam [3:0] ST_SEND_ADDR_W = 4'd3;
    localparam [3:0] ST_SEND_REG    = 4'd4;
    localparam [3:0] ST_SEND_WBYTE  = 4'd5;
    localparam [3:0] ST_REP_START_A = 4'd6;
    localparam [3:0] ST_REP_START_B = 4'd7;
    localparam [3:0] ST_SEND_ADDR_R = 4'd8;
    localparam [3:0] ST_READ_RBYTE  = 4'd9;
    localparam [3:0] ST_STOP_A      = 4'd10;
    localparam [3:0] ST_STOP_B      = 4'd11;
    localparam [3:0] ST_DONE        = 4'd12;
    localparam [3:0] ST_ERROR       = 4'd13;

    reg [3:0] st;

    reg [1:0] wleft;
    reg [2:0] rleft;

    reg [6:0] dev_addr_l;
    reg [7:0] reg_addr_l;
    reg [1:0] wlen_l;
    reg [23:0] wdata_l;
    reg [2:0] rlen_l;

    reg [31:0] rshift;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st        <= ST_IDLE;
            busy      <= 1'b0;
            done      <= 1'b0;
            rvalid    <= 1'b0;
            ack_error <= 1'b0;
            scl_high  <= 1'b1;
            scl_oe_n  <= 1'b1;
            sda_oe_n  <= 1'b1;
            dev_addr_l<= 7'd0;
            reg_addr_l<= 8'd0;
            wlen_l    <= 2'd0;
            wdata_l   <= 24'd0;
            rlen_l    <= 3'd0;
            rshift    <= 32'd0;
            rcount    <= 3'd0;
            rdata     <= 32'd0;
        end else begin
            done   <= 1'b0;
            rvalid <= 1'b0;

            if (st == ST_IDLE) begin
                scl_oe_n  <= 1'b1;
                sda_oe_n  <= 1'b1;
                scl_high  <= 1'b1;
                if (start && !busy) begin
                    dev_addr_l <= dev_addr;
                    reg_addr_l <= reg_addr;
                    wlen_l     <= wlen;
                    wdata_l    <= wdata;
                    rlen_l     <= rlen;
                    wleft      <= wlen;
                    rleft      <= rlen;
                    rshift     <= 32'd0;
                    rcount     <= 3'd0;
                    ack_error  <= 1'b0;
                    busy       <= 1'b1;
                    st         <= ST_START_A;
                end
            end else if (st == ST_START_A) begin
                if (tick) begin
                    sda_oe_n <= 1'b0;
                    st       <= ST_START_B;
                end
            end else if (st == ST_START_B) begin
                if (tick) begin
                    scl_oe_n <= 1'b0;
                    scl_high <= 1'b0;
                    byte_tx   <= {dev_addr_l, 1'b0};
                    bit_idx   <= 3'd7;
                    byte_phase<= 1'b0;
                    st        <= ST_SEND_ADDR_W;
                end
            end else if (st == ST_SEND_ADDR_W || st == ST_SEND_REG || st == ST_SEND_WBYTE || st == ST_SEND_ADDR_R) begin
                if (!byte_phase) begin
                    if (!scl_high && tick) {sda_oe_n, scl_oe_n, scl_high} <= {byte_tx[bit_idx] ? 1'b1 : 1'b0, 1'b1, 1'b1};
                    else if (scl_high && tick) begin
                        {scl_oe_n, scl_high} <= {1'b0, 1'b0};
                        if (bit_idx == 0) byte_phase <= 1'b1; else bit_idx <= bit_idx - 1;
                    end
                end else begin
                    if (!scl_high && tick) {sda_oe_n, scl_oe_n, scl_high} <= {1'b1, 1'b1, 1'b1};
                    else if (scl_high && tick) begin
                        if (sda_in && st != ST_SEND_ADDR_R) {ack_error, st} <= {1'b1, ST_ERROR};
                        else begin
                            {scl_oe_n, scl_high} <= {1'b0, 1'b0};
                            if (st == ST_SEND_ADDR_W) begin
                                byte_tx <= reg_addr_l; bit_idx <= 3'd7; byte_phase <= 1'b0; st <= ST_SEND_REG;
                            end else if (st == ST_SEND_REG) begin
                                if (wleft > 0) begin
                                    case(wleft)
                                        3: byte_tx <= wdata_l[23:16];
                                        2: byte_tx <= wdata_l[15:8];
                                        1: byte_tx <= wdata_l[7:0];
                                    endcase
                                    bit_idx <= 3'd7; byte_phase <= 1'b0; wleft <= wleft - 1; st <= ST_SEND_WBYTE;
                                end else if (rlen_l > 0) st <= ST_REP_START_A;
                                else st <= ST_STOP_A;
                            end else if (st == ST_SEND_WBYTE) begin
                                if (wleft > 0) begin
                                    case(wleft)
                                        3: byte_tx <= wdata_l[23:16];
                                        2: byte_tx <= wdata_l[15:8];
                                        1: byte_tx <= wdata_l[7:0];
                                    endcase
                                    bit_idx <= 3'd7; byte_phase <= 1'b0; wleft <= wleft - 1;
                                end else if (rlen_l > 0) st <= ST_REP_START_A;
                                else st <= ST_STOP_A;
                            end else if (st == ST_SEND_ADDR_R) begin
                                bit_idx <= 3'd7; byte_phase <= 1'b0; st <= ST_READ_RBYTE;
                            end
                        end
                    end
                end
            end else if (st == ST_READ_RBYTE) begin
                if (!byte_phase) begin
                    if (!scl_high && tick) {scl_oe_n, scl_high} <= {1'b1, 1'b1};
                    else if (scl_high && tick) begin
                        rshift <= {rshift[30:0], sda_in};
                        {scl_oe_n, scl_high} <= {1'b0, 1'b0};
                        if (bit_idx == 0) byte_phase <= 1'b1; else bit_idx <= bit_idx - 1;
                    end
                end else begin
                    if (!scl_high && tick) begin
                        sda_oe_n <= (rleft > 1) ? 1'b0 : 1'b1;
                        {scl_oe_n, scl_high} <= {1'b1, 1'b1};
                    end else if (scl_high && tick) begin
                        {scl_oe_n, scl_high} <= {1'b0, 1'b0};
                        sda_oe_n <= 1'b1;
                        rleft <= rleft - 1;
                        if (rleft > 1) begin bit_idx <= 3'd7; byte_phase <= 1'b0; end
                        else st <= ST_STOP_A;
                    end
                end
            end else if (st == ST_REP_START_A) begin
                if (tick) {sda_oe_n, scl_oe_n, scl_high} <= {1'b1, 1'b1, 1'b1};
                if (tick) st <= ST_REP_START_B;
            end else if (st == ST_REP_START_B) begin
                if (tick) begin
                    sda_oe_n <= 1'b0;
                    st <= ST_START_B;
                    byte_tx <= {dev_addr_l, 1'b1};
                    st <= ST_SEND_ADDR_R;
                end
            end else if (st == ST_STOP_A) begin
                if (tick) begin sda_oe_n <= 1'b0; st <= ST_STOP_B; end
            end else if (st == ST_STOP_B) begin
                if (tick) begin {scl_oe_n, scl_high} <= {1'b1, 1'b1}; st <= ST_DONE; end
            end else if (st == ST_DONE) begin
                if (tick) begin
                    sda_oe_n <= 1'b1;
                    if (rlen_l > 0) begin
                        rcount <= rlen_l;
                        rdata <= rshift << (32 - rlen_l*8);
                        rvalid <= 1'b1;
                    end
                    done <= 1'b1;
                    busy <= 1'b0;
                    st <= ST_IDLE;
                end
            end else if (st == ST_ERROR) begin
                st <= ST_STOP_A;
            end
        end
    end
endmodule