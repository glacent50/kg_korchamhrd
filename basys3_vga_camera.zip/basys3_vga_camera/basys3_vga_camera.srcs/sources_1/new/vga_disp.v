`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/17/2025 09:55:08 AM
// Design Name: 
// Module Name: vga_disp
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// 640 X 480 @ 60Hz with a 25.000MHz pixel clock

module vga_disp(
    input clk25,
    output reg [3:0] vga_red,
    output reg [3:0] vga_green,
    output reg [3:0] vga_blue,
    output reg vga_hsync,
    output reg vga_vsync,
    output [9:0] HCnt,
    output [9:0] VCnt,

    output [16:0] frame_addr,
    input [11:0] frame_pixel
    );
    
    // 타이밍 상수
    parameter hRez = 640;
    parameter hStartSync = 640 + 16;
    parameter hEndSync = 640 + 16 + 96;
    parameter hMaxCount = 800;

    parameter vRez = 480;
    parameter vStartSync = 480 + 10;
    parameter vEndSync = 480 + 10 + 2;
    parameter vMaxCount = 480 + 10 + 2 + 33;

    parameter hsync_active = 0;
    parameter vsync_active = 0;
    reg [9:0] hCounter;
    reg [9:0] vCounter;
    reg [9:0] VCNT, HCNT;
    reg [16:0] address;
    reg blank;
    
    initial hCounter = 10'b0;
    initial vCounter = 10'b0;
    initial HCNT = 10'b0;
    initial VCNT = 10'b0;
    initial address = 17'b0;
    initial blank = 1'b1;

    assign frame_addr = address;
    //   assign HCnt = hCounter;
    //   assign VCnt = vCounter;
    assign HCnt = HCNT;
    assign VCnt = VCNT;
    
    always @(posedge clk25) begin
    
        if (hCounter == hMaxCount - 1) begin
            hCounter <= 10'b0;
            if (vCounter == vMaxCount - 1)
                vCounter <= 10'b0;
            else
                vCounter <= vCounter + 1;
        end 
        else begin
            hCounter <= hCounter + 1;
        end

        if (blank == 0) begin
            vga_red <= frame_pixel[11:8];
            vga_green <= frame_pixel[7:4];
            vga_blue <= frame_pixel[3:0];
        end 
        else begin
            vga_red <= 4'b0;
            vga_green <= 4'b0;
            vga_blue <= 4'b0;
        end


        if (vCounter >= vRez) begin
            // address <= 19'b0; 
            blank <= 1;
        end 
        else begin
            if (hCounter < 640) begin
                blank <= 0;
                // address <= address+1;
            end 
            else blank <= 1;
        end


        // hSync 펄스 구간인가? (frame_buffer_latency를 포함하기 위해 1 추가)
        if (hCounter > hStartSync && hCounter <= hEndSync)
            vga_hsync <= hsync_active;
        else vga_hsync <= ~hsync_active;

        // vSync 펄스 구간인가?
        if (vCounter >= vStartSync && vCounter < vEndSync) 
            vga_vsync <= vsync_active;
        else vga_vsync <= ~vsync_active;
  
    end

    always @(posedge vga_hsync) begin
        if (vga_vsync == 1) begin
            if (VCNT > 524) VCNT <= 0;
            else VCNT <= VCNT + 1;
        end    
        else begin
            VCNT <= 492;
        end
    end

    always @(posedge clk25) begin
        if (vga_hsync == 1) begin
            if (HCNT > 799) HCNT <= 0;
            else HCNT <= HCNT + 1;
        end    
        else HCNT <= 753;
    end

    always @(posedge clk25) begin
        if (VCNT >= 360 || VCNT < 120) begin
            address <= 17'b0;
        end 
        else begin
            if (HCNT < 480 && HCNT >= 160) begin
                address <= address + 1;
            end
        end
    end
    
endmodule
