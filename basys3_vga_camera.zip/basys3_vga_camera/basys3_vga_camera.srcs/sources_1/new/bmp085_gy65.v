`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/22/2025 11:15:47 AM
// Design Name: 
// Module Name: bmp085_gy65
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// BMP085 (GY-65) 간단한 컨트롤러: 주기적으로 온도 및 압력 변환을 트리거하고,
// I2C를 통해 원시 UT(16비트) 및 UP(20비트, 정렬됨)를 읽습니다.
// 참고: 이 모듈은 보정된 온도/압력을 계산하지 않습니다. 원시 UT/UP를 출력합니다.
module bmp085_gy65 #(
    parameter integer CLK_FREQ  = 100_000_000,
    parameter integer SAMPLE_MS = 100, // 측정 주기
    parameter integer OSS       = 0    // 0..3, 오버샘플링 설정
)(
    input  wire        clk,
    input  wire        rst_n,

    // I2C 라인
    inout  wire        i2c_scl,
    inout  wire        i2c_sda,

    // 원시 출력
    output reg  [15:0] ut,        // 16비트 원시 온도
    output reg         ut_valid,  // ut가 업데이트될 때 1-사이클 펄스
    output reg  [19:0] up,        // 오른쪽 정렬된 20비트 원시 압력
    output reg         up_valid,  // up이 업데이트될 때 1-사이클 펄스

    // 상태
    output reg         busy_cycle,
    output reg         i2c_error
);

    localparam [6:0] DEV_ADDR = 7'h77;

    wire m_busy, m_done, m_rvalid, m_ack_error;
    wire [31:0] m_rdata;
    reg m_start;
    reg [6:0] m_dev_addr;
    reg [7:0] m_reg_addr;
    reg [1:0] m_wlen;
    reg [23:0] m_wdata;
    reg [2:0] m_rlen;

    i2c_master_combined #(
        .CLK_FREQ(CLK_FREQ)
    ) i2c_master (
        .clk(clk), .rst_n(rst_n),
        .start(m_start), .dev_addr(m_dev_addr), .reg_addr(m_reg_addr),
        .wlen(m_wlen), .wdata(m_wdata), .rlen(m_rlen),
        .busy(m_busy), .done(m_done), .rvalid(m_rvalid), .ack_error(m_ack_error),
        .rdata(m_rdata),
        .i2c_scl(i2c_scl), .i2c_sda(i2c_sda)
    );

    localparam integer TEMP_WAIT_CYC = (CLK_FREQ/1000) * 5; // 5ms wait

    function integer press_delay_ms(input [1:0] oss);
        case(oss) 0: press_delay_ms=5; 1: press_delay_ms=8; 2: press_delay_ms=14; 3: press_delay_ms=26; endcase
    endfunction

    function integer ms_to_cycles(input integer ms);
        ms_to_cycles = (CLK_FREQ/1000) * ms;
    endfunction

    reg [31:0] wait_cnt;
    reg [31:0] press_wait_cycles;

    localparam [3:0] S_IDLE       = 4'd0;
    localparam [3:0] S_TRIG_TEMP  = 4'd1;
    localparam [3:0] S_WAIT_TEMP  = 4'd2;
    localparam [3:0] S_READ_UT    = 4'd3;
    localparam [3:0] S_TRIG_PRESS = 4'd4;
    localparam [3:0] S_WAIT_PRESS = 4'd5;
    localparam [3:0] S_READ_UP    = 4'd6;
    localparam [3:0] S_NEXT       = 4'd7;

    reg [3:0] st;

    reg [31:0] sample_cnt;
    localparam integer SAMPLE_CYCLES = (CLK_FREQ/1000) * SAMPLE_MS;

    wire mc_ready = !m_busy;

    reg [31:0] raw24;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE;
            m_start <= 1'b0;
            ut <= 16'd0; up <= 20'd0;
            ut_valid <= 1'b0; up_valid <= 1'b0;
            busy_cycle <= 1'b0; i2c_error <= 1'b0;
            sample_cnt <= 32'd0; wait_cnt <= 32'd0;
            press_wait_cycles <= ms_to_cycles(press_delay_ms(OSS));
        end else begin
            m_start <= 1'b0;
            ut_valid <= 1'b0; up_valid <= 1'b0;

            if (!busy_cycle) begin
                if (sample_cnt >= SAMPLE_CYCLES-1) sample_cnt <= 32'd0;
                else sample_cnt <= sample_cnt + 1;
            end

            case (st)
                S_IDLE: begin
                    busy_cycle <= 1'b0;
                    if (sample_cnt == SAMPLE_CYCLES-1) begin
                        busy_cycle <= 1'b1;
                        if (mc_ready) begin
                            m_dev_addr <= DEV_ADDR; m_reg_addr <= 8'hF4;
                            m_wlen <= 2'd1; m_wdata <= {16'd0, 8'h2E}; m_rlen <= 3'd0;
                            m_start <= 1'b1; st <= S_TRIG_TEMP;
                        end
                    end
                end
                S_TRIG_TEMP: if (m_done) begin wait_cnt <= 32'd0; st <= S_WAIT_TEMP; end
                S_WAIT_TEMP: begin
                    if (wait_cnt >= TEMP_WAIT_CYC-1) begin
                        if (mc_ready) begin
                            m_dev_addr <= DEV_ADDR; m_reg_addr <= 8'hF6;
                            m_wlen <= 2'd0; m_rlen <= 3'd2;
                            m_start <= 1'b1; st <= S_READ_UT;
                        end
                    end else wait_cnt <= wait_cnt + 1;
                end
                S_READ_UT: begin
                    if (m_done && m_rvalid) begin
                        ut <= {m_rdata[31:24], m_rdata[23:16]};
                        ut_valid <= 1'b1;
                        if (mc_ready) begin
                            m_dev_addr <= DEV_ADDR; m_reg_addr <= 8'hF4;
                            m_wlen <= 2'd1; m_wdata <= {16'd0, (8'h34 | (OSS[1:0] << 6))}; m_rlen <= 3'd0;
                            m_start <= 1'b1;
                            press_wait_cycles <= ms_to_cycles(press_delay_ms(OSS));
                            st <= S_TRIG_PRESS;
                        end
                    end
                end
                S_TRIG_PRESS: if (m_done) begin wait_cnt <= 32'd0; st <= S_WAIT_PRESS; end
                S_WAIT_PRESS: begin
                    if (wait_cnt >= press_wait_cycles-1) begin
                        if (mc_ready) begin
                            m_dev_addr <= DEV_ADDR; m_reg_addr <= 8'hF6;
                            m_wlen <= 2'd0; m_rlen <= 3'd3;
                            m_start <= 1'b1; st <= S_READ_UP;
                        end
                    end else wait_cnt <= wait_cnt + 1;
                end
                S_READ_UP: begin
                    if (m_done && m_rvalid) begin
                        raw24 = {m_rdata[31:8], 8'd0} >> (8 - OSS[1:0]);
                        up <= raw24[19:0];
                        up_valid <= 1'b1;
                        st <= S_NEXT;
                    end
                end
                S_NEXT: begin busy_cycle <= 1'b0; st <= S_IDLE; end
                default: st <= S_IDLE;
            endcase
            if (m_ack_error) i2c_error <= 1'b1;
        end
    end
endmodule

