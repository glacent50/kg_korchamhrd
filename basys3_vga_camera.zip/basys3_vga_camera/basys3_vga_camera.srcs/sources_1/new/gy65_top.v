`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/22/2025 11:21:59 AM
// Design Name: 
// Module Name: gy65_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// I2C를 통해 BMP085(GY-65)와 인터페이스하는 Basys3 최상위 예제.
// - 클럭: 100 MHz (Basys3)
// - 리셋: btnC (active-low)
// - I2C: Pmod 헤더에 연결 (SCL, SDA).
// - LED: 원시 온도 값 UT[15:0]을 표시.
module gy65_top (
    input  wire clk100,
    input  wire reset_p,

    // Pmod 헤더로 가는 I2C 라인
    inout  wire JA_SCL,
    inout  wire JA_SDA,

    output wire [15:0] LED
);
    wire rst_n = ~reset_p;

    wire [15:0] ut;

    bmp085_gy65 #(
        .CLK_FREQ(100_000_000),
        .SAMPLE_MS(100),
        .OSS(0)
    ) u_gy65 (
        .clk(clk100),
        .rst_n(rst_n),
        .i2c_scl(JA_SCL),
        .i2c_sda(JA_SDA),
        .ut(ut)
        // 다른 출력은 이 예제에서 사용되지 않음
    );

    assign LED = ut;

endmodule
