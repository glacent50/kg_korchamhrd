`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/09/22 21:35:22
// Design Name: 
// Module Name: I2C_Controller
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module I2C_Controller 
(
	//Global iCLK
	input				iCLK,		
	input				iRST_N,		
	
	//I2C transfer
	input				I2C_CLK,	//DATA Transfer Enable
	input				I2C_EN,		//I2C DATA ENABLE
	input		[23:0]	I2C_WDATA,	//DATA:[SLAVE_ADDR, SUB_ADDR, DATA]
	output				I2C_SCLK,	//I2C iCLK
 	inout				I2C_SDAT,	//I2C DATA
	input				WR,     	//Write | Read
	input				GO,      	//GO transfor
	output				ACK,      	//ACK
	output	reg			END,     	//END transfor 
	output	reg	[7:0]	I2C_RDATA	//I2C Data read
);

//------------------------------------
//I2C Signal
reg		I2C_BIT;
reg 	SCLK;	//I2C Free Clock
reg	[5:0]	SD_COUNTER;

//Write: ID-Address + SUB-Address + W-Data
wire 	I2C_SCLK1 = 	(GO == 1 &&
						((SD_COUNTER >= 5 && SD_COUNTER <=12 || SD_COUNTER == 14) ||	
						(SD_COUNTER >= 16 && SD_COUNTER <=23 || SD_COUNTER == 25) ||
						(SD_COUNTER >= 27 && SD_COUNTER <=34 || SD_COUNTER == 36))) ? I2C_CLK : SCLK;

//I2C Read: {ID-Address + SUB-Address} + {ID-Address + R-Data}						
wire 	I2C_SCLK2 = 	(GO == 1 &&
						((SD_COUNTER >= 5 && SD_COUNTER <=12 || SD_COUNTER == 14) ||
						(SD_COUNTER >= 16 && SD_COUNTER <=23 || SD_COUNTER == 25) ||
						(SD_COUNTER >= 33 && SD_COUNTER <=40 || SD_COUNTER == 42) ||
						(SD_COUNTER >= 45 && SD_COUNTER <=52 || SD_COUNTER == 54))) ? I2C_CLK : SCLK;						
assign	I2C_SCLK = WR ? I2C_SCLK1 : I2C_SCLK2;	

wire	SDO1	=		((SD_COUNTER == 13 || SD_COUNTER == 14)|| 
						(SD_COUNTER == 24 || SD_COUNTER == 25) || 
						(SD_COUNTER == 35 || SD_COUNTER == 36)) ? 1'b0 : 1'b1;		//input | output
						
wire	SDO2	=		((SD_COUNTER == 13 || SD_COUNTER == 14)|| 
						(SD_COUNTER == 24 || SD_COUNTER == 25) || 
						(SD_COUNTER == 41 || SD_COUNTER == 42) ||
						(SD_COUNTER >= 44 && SD_COUNTER <= 52)) ? 1'b0 : 1'b1;		//input | output
wire	SDO = WR ? SDO1 : SDO2;
assign	I2C_SDAT = SDO ? I2C_BIT : 1'bz;



//------------------------------------
//Write ACK | Read ACK
reg		ACKW1, ACKW2, ACKW3;		//0 AVTIVE
reg 	ACKR1, ACKR2, ACKR3;		//0 ACTIVE
assign	ACK = WR ? (ACKW1 | ACKW2 | ACKW3) : (ACKR1 | ACKR2 | ACKR3);


//------------------------------------
//I2C COUNTER
always @(posedge iCLK or negedge iRST_N) 
begin
	if (!iRST_N) 
		SD_COUNTER <= 6'b0;
	else if(I2C_EN)
		begin
		if (GO == 0 || END == 1) 
			SD_COUNTER <= 6'b0;
		else if (SD_COUNTER < 6'd63) 
			SD_COUNTER <= SD_COUNTER + 6'd1;	
		end
	else
		SD_COUNTER <= SD_COUNTER;
end

//------------------------------------
//I2C Transfer
always @(posedge iCLK or negedge iRST_N) 
begin
    if(!iRST_N) 
		begin 
		SCLK <= 1;
		I2C_BIT <= 1; 
		ACKW1 <= 1; ACKW2 <= 1; ACKW3 <= 1; 
		ACKR1 <= 1; ACKR2 <= 1; ACKR3 <= 1;
		END <= 0;
		I2C_RDATA <= 8'h0;	
		end
	else if(I2C_EN)		//data change enable
		begin
		if(GO)
			begin
			if(WR)		//I2C Write: ID-Address + SUB-Address + W-Data
				begin
				case(SD_COUNTER)
				//IDLE
				6'd0 :	begin
						SCLK <= 1;
						I2C_BIT <= 1;
						ACKW1 <= 1; ACKW2 <= 1; ACKW3 <= 1;
						ACKR1 <= 1; ACKR2 <= 1; ACKR3 <= 1;
						END <= 0;
						end
				//Start
				6'd1 :	begin 
						SCLK <= 1;
						I2C_BIT <= 1;
						ACKW1 <= 1; ACKW2 <= 1; ACKW3 <= 1; 
						END <= 0;
						end
				6'd2  : I2C_BIT <= 0;		//I2C_SDAT = 0
				6'd3  : SCLK <= 0;			//I2C_SCLK = 0
				
				//SLAVE ADDR--ACK1
				6'd4  : I2C_BIT <= I2C_WDATA[23];	//Bit8
				6'd5  : I2C_BIT <= I2C_WDATA[22];	//Bit7
				6'd6  : I2C_BIT <= I2C_WDATA[21];	//Bit6
				6'd7  : I2C_BIT <= I2C_WDATA[20];	//Bit5
				6'd8  : I2C_BIT <= I2C_WDATA[19];	//Bit4
				6'd9  : I2C_BIT <= I2C_WDATA[18];	//Bit3
				6'd10 : I2C_BIT <= I2C_WDATA[17];	//Bit2
				6'd11 : I2C_BIT <= I2C_WDATA[16];	//Bit1
				6'd12 : I2C_BIT <= 0;				//High-Z, Input
				6'd13 : ACKW1 	<= I2C_SDAT;		//ACK1
				6'd14 : I2C_BIT <= 0;				//Delay
				
				//SUB ADDR--ACK2
				6'd15 : I2C_BIT <= I2C_WDATA[15];	//Bit8
				6'd16 : I2C_BIT <= I2C_WDATA[14];	//Bit7
				6'd17 : I2C_BIT <= I2C_WDATA[13];	//Bit6
				6'd18 : I2C_BIT <= I2C_WDATA[12];	//Bit5
				6'd19 : I2C_BIT <= I2C_WDATA[11];	//Bit4
				6'd20 : I2C_BIT <= I2C_WDATA[10];	//Bit3
				6'd21 : I2C_BIT <= I2C_WDATA[9];   //Bit2
				6'd22 : I2C_BIT <= I2C_WDATA[8];	//Bit1
				6'd23 : I2C_BIT <= 0;				//High-Z, Input
				6'd24 : ACKW2 	<= I2C_SDAT;		//ACK2
				6'd25 : I2C_BIT <= 0;				//Delay
				
				//Write DATA--ACK3
				6'd26 : I2C_BIT <= I2C_WDATA[7];	//Bit8 
				6'd27 : I2C_BIT <= I2C_WDATA[6];	//Bit7
				6'd28 : I2C_BIT <= I2C_WDATA[5];	//Bit6
				6'd29 : I2C_BIT <= I2C_WDATA[4];	//Bit5
				6'd30 : I2C_BIT <= I2C_WDATA[3];	//Bit4
				6'd31 : I2C_BIT <= I2C_WDATA[2];	//Bit3
				6'd32 : I2C_BIT <= I2C_WDATA[1];	//Bit2
				6'd33 : I2C_BIT <= I2C_WDATA[0];	//Bit1
				6'd34 : I2C_BIT <= 0;				//High-Z, Input
				6'd35 : ACKW3 	<= I2C_SDAT;		//ACK3
				6'd36 : I2C_BIT <= 0;				//Delay

				//Stop
				6'd37 : begin	SCLK <= 0; I2C_BIT <= 0; end
				6'd38 : SCLK <= 1;	
				6'd39 : begin I2C_BIT <= 1; END <= 1; end 
				default : begin I2C_BIT <= 1; SCLK <= 1; end
				endcase
				end
			else		//I2C Read: {ID-Address + SUB-Address} + {ID-Address + R-Data}
				begin
				case(SD_COUNTER)
				//IDLE
				6'd0 :	begin
						SCLK <= 1;
						I2C_BIT <= 1;
						ACKW1 <= 1; ACKW2 <= 1; ACKW3 <= 1;
						ACKR1 <= 1; ACKR2 <= 1; ACKR3 <= 1; 
						END <= 0;
						end
				//I2C Read1: {ID-Address + SUB-Address}
				//Start
				6'd1 :	begin 
						SCLK <= 1;
						I2C_BIT <= 1;
						ACKR1 <= 1; ACKR2 <= 1; ACKR3 <= 1; 
						END <= 0;
						end
				6'd2  : I2C_BIT <= 0;		//I2C_SDAT = 0
				6'd3  : SCLK <= 0;			//I2C_SCLK = 0
				
				//SLAVE ADDR--ACK1
				6'd4  : I2C_BIT <= I2C_WDATA[23];	//Bit8
				6'd5  : I2C_BIT <= I2C_WDATA[22];	//Bit7
				6'd6  : I2C_BIT <= I2C_WDATA[21];	//Bit6
				6'd7  : I2C_BIT <= I2C_WDATA[20];	//Bit5
				6'd8  : I2C_BIT <= I2C_WDATA[19];	//Bit4
				6'd9  : I2C_BIT <= I2C_WDATA[18];	//Bit3
				6'd10 : I2C_BIT <= I2C_WDATA[17];	//Bit2
				6'd11 : I2C_BIT <= I2C_WDATA[16];	//Bit1
				6'd12 : I2C_BIT <= 0;				//High-Z, Input
				6'd13 : ACKR1 	<= I2C_SDAT;		//ACK1
				6'd14 : I2C_BIT <= 0;				//Delay
				
				//SUB ADDR--ACK2
				6'd15 : I2C_BIT <= I2C_WDATA[15];	//Bit8
				6'd16 : I2C_BIT <= I2C_WDATA[14];	//Bit7
				6'd17 : I2C_BIT <= I2C_WDATA[13];	//Bit6
				6'd18 : I2C_BIT <= I2C_WDATA[12];	//Bit5
				6'd19 : I2C_BIT <= I2C_WDATA[11];	//Bit4
				6'd20 : I2C_BIT <= I2C_WDATA[10];	//Bit3
				6'd21 : I2C_BIT <= I2C_WDATA[9];    //Bit2
				6'd22 : I2C_BIT <= I2C_WDATA[8];	//Bit1
				6'd23 : I2C_BIT <= 0;				//High-Z, Input
				6'd24 : ACKR2 	<= I2C_SDAT;		//ACK2
				6'd25 : I2C_BIT <= 0;				//Delay

				//Stop
				6'd26 : begin	SCLK <= 0; I2C_BIT <= 0; end
				6'd27 : SCLK <= 1;	
				6'd28 : begin I2C_BIT <= 1; /*END <= 1;*/end 

				//I2C Read2: {ID-Address + R-Data}
				//Start
				6'd29 :	begin 
						SCLK <= 1;
						I2C_BIT <= 1;
						end
				6'd30 : I2C_BIT <= 0;		//I2C_SDAT = 0
				6'd31 : SCLK <= 0;			//I2C_SCLK = 0
				
				//SLAVE ADDR--ACK3
				6'd32 : I2C_BIT <= I2C_WDATA[23];	//Bit8
				6'd33 : I2C_BIT <= I2C_WDATA[22];	//Bit7
				6'd34 : I2C_BIT <= I2C_WDATA[21];	//Bit6
				6'd35 : I2C_BIT <= I2C_WDATA[20];	//Bit5
				6'd36 : I2C_BIT <= I2C_WDATA[19];	//Bit4
				6'd37 : I2C_BIT <= I2C_WDATA[18];	//Bit3
				6'd38 : I2C_BIT <= I2C_WDATA[17];	//Bit2
				6'd39 : I2C_BIT <= 1'b1;			//Bit1	Read Data Flag
				6'd40 : I2C_BIT <= 0;				//High-Z, Input
				6'd41 : ACKR3 	<= I2C_SDAT;		//ACK3
				6'd42 : I2C_BIT <= 0;				//Delay
				
				//Read DATA--ACK4
				6'd43 : I2C_BIT 	<= 0;			//Delay
				6'd44 : I2C_BIT 	<= 0;			//High-Z, Input
				6'd45 : I2C_RDATA[7] <= I2C_SDAT;	//Bit8	, Input
				6'd46 : I2C_RDATA[6] <= I2C_SDAT;	//Bit7	, Input 
				6'd47 : I2C_RDATA[5] <= I2C_SDAT;	//Bit6	, Input 
				6'd48 : I2C_RDATA[4] <= I2C_SDAT;	//Bit5	, Input 
				6'd49 : I2C_RDATA[3] <= I2C_SDAT;	//Bit4	, Input 
				6'd50 : I2C_RDATA[2] <= I2C_SDAT;	//Bit3	, Input 
				6'd51 : I2C_RDATA[1] <= I2C_SDAT;	//Bit2	, Input 
				6'd52 : I2C_RDATA[0] <= I2C_SDAT;	//Bit1	, Input 	
				6'd53 : I2C_BIT 	<= 1;			//Output //ACK4 NACK
				6'd54 : I2C_BIT 	<= 0;			//Delay
				
				//Stop
				6'd55 : begin	SCLK <= 0; I2C_BIT <= 0; end
				6'd56 : SCLK <= 1;	
				6'd57 : begin I2C_BIT <= 1; END <= 1; end 
				default : begin I2C_BIT <= 1; SCLK <= 1; end
				endcase
				end
			end
		else
			begin
			SCLK <= 1;
			I2C_BIT <= 1; 
			ACKW1 <= 1; ACKW2 <= 1; ACKW3 <= 1; 
			ACKR1 <= 1; ACKR2 <= 1; ACKR3 <= 1;
			END <= 0;
			I2C_RDATA <= I2C_RDATA;
			end
		end
end
		
endmodule



module	I2C_OV7670_RGB565_Config
(
	input		[7:0]	LUT_INDEX,
	output	reg	[15:0]	LUT_DATA)
;


parameter	Read_DATA	=	0;			//Read data LUT Address
parameter	SET_OV7670	=	2;			//SET_OV LUT Adderss
/////////////////////	Config Data LUT	  //////////////////////////	
always@(*)
begin
	case(LUT_INDEX)
		// --- 선행 Read: 칩 ID 확인 ---
		Read_DATA + 0  :  LUT_DATA = 16'h0A00; // PID 레지스터 (0x0A), 읽기 전용
		Read_DATA + 1  :  LUT_DATA = 16'h0B00; // VER 레지스터 (0x0B), 읽기 전용
		
		// --- 핵심 설정: QVGA (320x240) 및 RGB565 포맷 ---
		SET_OV7670 + 0  : LUT_DATA = 16'h1280; // COM7: 모든 레지스터 리셋 (초기화)
		SET_OV7670 + 1  : LUT_DATA = 16'h1204; // COM7: QVGA 포맷, RGB 출력 선택
		SET_OV7670 + 2  : LUT_DATA = 16'h40D0; // COM15: 출력 범위 [0-255], RGB565 포맷
		SET_OV7670 + 3  : LUT_DATA = 16'h1101; // CLKRC: 내부 클럭 프리스케일러 1:2 (XCLK 25MHz -> 12.5MHz)
		
		// --- 해상도 및 프레임 창 설정 (QVGA 기본값) ---
		SET_OV7670 + 4  : LUT_DATA = 16'h1713; // HSTART: 수평 프레임 시작 상위 8비트 (기본값)
		SET_OV7670 + 5  : LUT_DATA = 16'h1801; // HSTOP: 수평 프레임 끝 상위 8비트 (기본값)
		SET_OV7670 + 6  : LUT_DATA = 16'h1902; // VSTRT: 수직 프레임 시작 상위 8비트 (기본값)
		SET_OV7670 + 7  : LUT_DATA = 16'h1a7a; // VSTOP: 수직 프레임 끝 상위 8비트 (기본값)
		SET_OV7670 + 8  : LUT_DATA = 16'h030a; // VREF: 수직 프레임 제어 (기본값)
		SET_OV7670 + 9  : LUT_DATA = 16'h3212; // HREF: HREF 제어 (기본값)

		// --- 스케일링 비활성화 (네이티브 QVGA 사용) ---
		SET_OV7670 + 10 : LUT_DATA = 16'h0c00; // COM3: 스케일링 및 DCW 비활성화
		SET_OV7670 + 11 : LUT_DATA = 16'h3e00; // COM14: PCLK 스케일링 비활성화
		SET_OV7670 + 12 : LUT_DATA = 16'h703a; // SCALING_XSC: 수평 스케일링 (QVGA 기본값)
		SET_OV7670 + 13 : LUT_DATA = 16'h7135; // SCALING_YSC: 수직 스케일링 (QVGA 기본값)
		SET_OV7670 + 14 : LUT_DATA = 16'h7211; // SCALING_DCWCTR: DCW 및 다운샘플링 제어 (QVGA 기본값)
		SET_OV7670 + 15 : LUT_DATA = 16'h7300; // SCALING_PCLK_DIV: PCLK 분주 제어 (분주 없음)
		SET_OV7670 + 16 : LUT_DATA = 16'ha202; // SCALING_PCLK_DELAY: PCLK 지연 제어

		// --- 이미지 품질 및 색상 설정 ---
		SET_OV7670 + 17 : LUT_DATA = 16'h13e5; // COM8: AGC, AWB, AEC 활성화
		SET_OV7670 + 18 : LUT_DATA = 16'h1438; // COM9: AGC 최대치 설정 (4x)
		SET_OV7670 + 19 : LUT_DATA = 16'h0e00; // COM5: 일반 모드
		SET_OV7670 + 20 : LUT_DATA = 16'h0100; // GAIN: AGC 게인 설정
		SET_OV7670 + 21 : LUT_DATA = 16'h1000; // AECH: 노출값 설정
		
		// --- 추가 포맷 설정 ---
		SET_OV7670 + 22 : LUT_DATA = 16'h8c00; // RGB444: 비활성화 (COM15가 우선)
		SET_OV7670 + 23 : LUT_DATA = 16'h1520; // COM10: PCLK 출력 토글 비활성화, HREF를 HSYNC로 사용
		
	default		 :	LUT_DATA	=	0;
	endcase
end

endmodule

