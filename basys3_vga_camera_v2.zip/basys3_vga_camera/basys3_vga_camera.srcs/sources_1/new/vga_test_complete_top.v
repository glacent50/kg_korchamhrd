`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/19/2025 05:25:40 PM
// Design Name: 
// Module Name: vga_test_complete_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module vga_test_complete_top(
    input clk100,              // 100MHz 시스템 클럭
    input reset_p,             // 리셋 버튼 (Center button)
    input [1:0] pattern_sel,   // 테스트 패턴 선택 (00:컬러바, 01:체크보드, 10:그라데이션, 11:고정색상)
    output [3:0] vga_red,   
    output [3:0] vga_green,
    output [3:0] vga_blue,
    output vga_hsync,
    output vga_vsync,
    output [3:0] LED           // 디버깅용 LED
);
    
    // 내부 신호 선언
    wire reset;             // 내부 리셋 신호
    wire [9:0] h_cnt, v_cnt;
    wire [16:0] frame_addr;
    wire [11:0] frame_pixel;
    
    // 메모리 초기화용 신호들
    reg [16:0] init_addr;
    reg [11:0] init_data;
    reg init_we;
    reg init_done;
    reg [19:0] init_counter;
    reg [19:0] pixel_x, pixel_y;  // 좌표 계산용 변수
    
    // 리셋 신호 (Active Low로 변환)
    assign reset = !reset_p;
    
    
    wire  clk25;         // 25MHz VGA 클럭
    wire  clk50;         // 50MHz Reset 클럭
    clk_wiz_0 clk_div(
        .clk_in1 (clk100),
        .clk_out1  (clk50),
        .clk_out2 (clk25)
    );
        
    // VGA 컨트롤러 인스턴스화
    vga_disp vga_controller (
        .clk25(clk25),
        .vga_red(vga_red),
        .vga_green(vga_green),
        .vga_blue(vga_blue),
        .vga_hsync(vga_hsync),
        .vga_vsync(vga_vsync),
        .HCnt(h_cnt),
        .VCnt(v_cnt),
        .frame_addr(frame_addr),
        .frame_pixel(frame_pixel)
    );
    
    // Block Memory Generator IP 인스턴스화
    // Vivado에서 생성된 blk_mem_gen_0 IP를 사용
    blk_mem_gen_0 frame_buffer (
        // Port A - 초기화 및 쓰기용
        .clka(clk50),
        .wea(init_we),
        .addra(init_done ? 17'd0 : init_addr),
        .dina(init_data),
        
        // Port B - 읽기용 (VGA 출력)
        .clkb(clk25),
        .addrb(frame_addr),
        .doutb(frame_pixel)
    );    
    
    // 640 X 480 @ 60Hz with a 25.000MHz pixel clock
    // 메모리 초기화 상태 머신 (320x240 프레임버퍼)
    always @(posedge clk50 or negedge reset) begin
        if (!reset) begin
            init_counter <= 0;
            init_addr <= 0;
            init_we <= 1;
            init_done <= 0;
            init_data <= 0;
        end else begin
            if (!init_done) begin
                // 320x240 = 76,800 픽셀로 프레임버퍼 초기화
                // VGA 출력 시 각 픽셀이 2x2로 확대되어 640x480으로 표시됨
                if (init_counter < 76800) begin
                    init_addr <= init_counter[16:0];
                    
                    // 320x240 좌표 계산
                    pixel_x = init_counter % 320;
                    pixel_y = init_counter / 320;
                    
                    // 테스트 패턴 생성 (320x240 기준)
                    case (pattern_sel)
                        2'b00: begin // 컬러 바 패턴 (320 픽셀을 8등분)
                            if (pixel_x < 40)
                                init_data <= 12'hF00; // 빨간색
                            else if (pixel_x < 80)
                                init_data <= 12'h0F0; // 녹색
                            else if (pixel_x < 120)
                                init_data <= 12'h00F; // 파란색
                            else if (pixel_x < 160)
                                init_data <= 12'hFF0; // 노란색
                            else if (pixel_x < 200)
                                init_data <= 12'hF0F; // 마젠타
                            else if (pixel_x < 240)
                                init_data <= 12'h0FF; // 사이안
                            else if (pixel_x < 280)
                                init_data <= 12'hFFF; // 흰색
                            else
                                init_data <= 12'h000; // 검은색
                        end
                        
                        2'b01: begin // 체크보드 패턴 (20x20 블록)
                            if (((pixel_y / 20) % 2) == ((pixel_x / 20) % 2))
                                init_data <= 12'hFFF; // 흰색
                            else
                                init_data <= 12'h000; // 검은색
                        end
                        
                        2'b10: begin // 그라데이션 패턴
                            init_data <= {
                                pixel_x[7:4],  // Red (0-15)
                                pixel_y[7:4],  // Green (0-15) 
                                (pixel_x[7:4] + pixel_y[7:4]) >> 1  // Blue
                            };
                        end
                        
                        2'b11: begin // 고정 색상 (연한 파란색)
                            init_data <= 12'h8CF;
                        end
                    endcase
                    
                    init_counter <= init_counter + 1;
                    init_we <= 1;
                end else begin
                    init_done <= 1;
                    init_we <= 0;
                end
            end
        end
    end
    

    
    // LED 디버그 출력
    assign LED[0] = clk25;
    assign LED[1] = init_done;
    assign LED[2] = vga_hsync;
    assign LED[3] = vga_vsync;

endmodule
