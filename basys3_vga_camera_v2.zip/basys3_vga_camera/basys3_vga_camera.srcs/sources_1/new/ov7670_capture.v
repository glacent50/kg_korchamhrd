`timescale 1ns / 1ps

module ov7670_capture(
    input pclk,
    input vsync,
    input href,
    input[7:0] d_in,
    output[16:0] addr,
    output reg [11:0] dout,
    output reg we
);
    // 내부 레지스터
    reg [15:0] d_latch;           // 2바이트 픽셀 래치 (RGB565)
    reg [16:0] address;           // 현재 쓰기 주소 (0..76799)
    reg [1:0]  wr_hold;           // 2바이트 수집을 위한 토글 신호
    reg        prev_href;         // HREF 상승 에지 검출용

    // 초기화
    initial begin
        d_latch = 16'b0;
        address = 17'b0;
        wr_hold = 2'b0;
        prev_href = 1'b0;
        we      = 1'b0;
    end

    // 출력 포트 연결
    assign addr = address;
    // 현재 바이트(d_in)와 이전 바이트(d_latch[7:0])를 결합한 16비트 픽셀
    wire [15:0] pixel16 = {d_latch[7:0], d_in};

    // 픽셀 캡처 로직
    always @(posedge pclk) begin
        // VSYNC(프레임 시작) 신호가 오면 주소와 상태를 초기화
        if (vsync) begin
            address <= 17'd0;
            wr_hold <= 2'b0;
            we      <= 1'b0;
        end else begin
            // 기본적으로 we 신호는 비활성화
            we <= 1'b0;

            // HREF(유효 픽셀 구간)가 활성화된 동안에만 동작
            if (href) begin
                // 라인 시작 시 바이트 정렬 초기화
                prev_href <= href;
                if (href && !prev_href) begin
                    wr_hold <= 2'b0; // 라인 첫 바이트부터 다시 2바이트 정렬 시작
                end
                // 8비트씩 2번 들어오는 데이터를 16비트 d_latch에 저장
                d_latch <= {d_latch[7:0], d_in};
                
                // 2바이트(1픽셀)가 모두 수신되었는지 확인
                // wr_hold는 pclk마다 0->1->0->1... 토글됨
                wr_hold <= {wr_hold[0], ~wr_hold[0]};

                // 2번째 바이트가 들어왔을 때 (1픽셀 완성)
                if (wr_hold[1]) begin
                    // 버퍼 오버플로우 방지
                    if (address < 17'd76800) begin
                        // RGB565 -> RGB444 변환 후 출력 레지스터에 적재
                        // R(5)G(6)B(5) -> R(4)G(4)B(4)
                        dout <= {pixel16[15:12], pixel16[10:7], pixel16[4:1]};  // 기존 RGB444 전체
                        //dout <= {pixel16[15:12], 4'b0000, 4'b0000};  // 테스트: Red만 활성화
                        //dout <= {4'b0000, 4'b0000, pixel16[4:1]};  // 테스트: Blue만 활성화
                        // BRAM에 쓰기 신호(we)를 한 클럭 동안 활성화
                        we <= 1'b1;
                        // 다음 주소로 이동
                        address <= address + 1'b1;
                    end
                end
            end
        end
    end
endmodule

