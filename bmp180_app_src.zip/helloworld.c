/******************************************************************************
* Copyright (C) 2023 Advanced Micro Devices, Inc. All Rights Reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/
/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "sleep.h"
#include "xiic.h"
#include "bmp180.h"

int main()
{
    init_platform();

    // BMP180 초기화
    if (bmp180_init() != 0) {
        printf("BMP180 initialization failed!\r\n");
        cleanup_platform();
        return -1;
    }

    // 메인 루프
    int count = 0;
    BMP180_ResultData bmpResultData;
    bmpResultData.pressure = 0;
    bmpResultData.pressureMod = 0;
    bmpResultData.temperature = 0;
    bmpResultData.temperatureMod = 0;
    bmpResultData.altitude = 0;

    while (1) {
        printf("====================================\r\n");
        printf("BMP180 Sensor Reading #%d\r\n", ++count);
        if (bmp180_GetResultData(&bmpResultData) == 1) {
            printf("Temperature: %d.%d°C\r\n", bmpResultData.temperature, bmpResultData.temperatureMod);
            printf("Pressure:    %d.%d hPa\r\n", bmpResultData.pressure, bmpResultData.pressureMod); 
            if (bmpResultData.altitude > 0) {
                printf("Altitude:    %d m\r\n", bmpResultData.altitude);
            } else {
                printf("Altitude:    ERROR\r\n");
            }
        } else {
            printf("bmp180_GetResultData:    ERROR\r\n");
        }
        printf("====================================\r\n");

        // 1초 대기
        sleep(1);
    }

    cleanup_platform();
    return 0;
}
